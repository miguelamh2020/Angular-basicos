/*
    ===== Código de TypeScript =====
*/

